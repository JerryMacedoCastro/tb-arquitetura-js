import React from 'react';

const Load = () => {
  return (
    <div className="p-3">
      <div className="spinner-border" role="status"></div>;
    </div>
  );
};

export default Load;
